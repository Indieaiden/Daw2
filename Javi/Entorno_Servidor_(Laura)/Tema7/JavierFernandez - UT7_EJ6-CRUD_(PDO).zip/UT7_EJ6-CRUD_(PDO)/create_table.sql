CREATE Table salario (
dni_empleado varchar(10) PRIMARY KEY,
nombre_empleado varchar(50) not null,
puesto_empleado varchar(30),
sueldo_empleado dec(6,2) not null
);