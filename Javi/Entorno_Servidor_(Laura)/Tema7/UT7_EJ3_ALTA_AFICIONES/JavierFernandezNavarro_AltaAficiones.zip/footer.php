<?php
function creaFooter(){
	?>
</body>
</html>
	<?php
}
 ?>
