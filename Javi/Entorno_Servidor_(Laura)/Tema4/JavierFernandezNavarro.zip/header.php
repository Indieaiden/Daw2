<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="UTF-8" />
		<title>Piece of Log</title>
		<meta name="description" content="Guardar un log en un documento externo">
		<meta name="author" content="Javier">
	</head>
	<body>
