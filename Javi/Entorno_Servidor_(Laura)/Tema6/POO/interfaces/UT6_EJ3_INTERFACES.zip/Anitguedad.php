<?php
/*interfaz que define la antiguedad de un objeto*/
Interface pEdad{
  public function getEdad();
  public function setEdad($edad);
}
?>
