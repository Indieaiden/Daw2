<?php
/*Clase Persona que define el estado de una perosna, implementa la Interfaz Antiguedad para definir su edad.
Proiedade: Nombre, Apellidos, Genero
Metodos: setters y getters de las otras propiedades

*/
// Incluimos el archivo con la interfazz
require_once("Antiguedad.php");

class Persona implements pEdad{
  // Propiedades
  private $nombre;
  private $apellidos;
  private $genero;
  // Constructor:
  function Persona() {
  }
  // Métodos:
  function getNombre() {
    return $this->nombre;
  }
  public function setNombre( $nombre ) {
    $this->nombre = $nombre;
  }
  public function getApellidos() {
    return $this->apellidos;
  }
  public function setApellidos( $apellidos ) {
    $this->apellidos = $apellidos;
  }
  // Métodos obligatorios según la interface (si se elimina alguno se generará un error):
  public function getGenero() {
    return $this->genero;
  }
  public function setGenero( $genero ) {
    $this->genero = $genero;
  }
}
?>
