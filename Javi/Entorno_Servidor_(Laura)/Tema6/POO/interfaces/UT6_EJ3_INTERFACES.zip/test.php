<?php
//test clases interfaz
require_once("Persona.php");//la Clase

$luisa = new Persona();

$luisa->setNombre("Luisa");
$luisa->setApellidos("Perez");
$luisa->setEdad(19);//de la interfaz

echo "Nombre: ".$luisa->getNombre()."<br/>";
echo "Apellidos: ".$luisa->getApellidos()."<br/>";
echo "Edad:: ".$luisa->getGenero()."<br/>";
?>
