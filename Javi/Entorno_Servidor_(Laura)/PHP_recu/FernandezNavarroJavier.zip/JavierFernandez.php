<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>index</title>
  </head>
  <body>
    <h1>EXAMEN</h1>
    <a href="Ejercicio1/acceso.php">Ejercicio 1</a>
    <br>
    <a href="Clases/juego.php?jugador1=pepe&jugador2=Luis">Ejercicio 2 (Con datos GET)</a>
    <br>
    <a href="Clases/juego.php">Ejercicio 2 (Sin GET)</a>
  </body>
</html>
