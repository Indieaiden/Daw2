<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" name="jorge" content="Tabla de multiplicar">
    <title>Tabla Multiplicar</title>
  </head>

	<body>
