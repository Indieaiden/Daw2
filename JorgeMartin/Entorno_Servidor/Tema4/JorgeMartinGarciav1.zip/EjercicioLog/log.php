<?php include_once "header.php" ?>
<?php

if (!$fp = fopen("log.log", "a")){
  echo "No se ha podido abrir el archivo";
}

  function addLog ($fp) {
        $time = time();
        fwrite($fp, "\r\n");
        fwrite($fp, __FUNCTION__ . " -- ");
        fwrite($fp, $_SERVER['PHP_SELF']." -- ");
        fwrite ($fp, date("H:i:s", $time));
  }

  addLog($fp);

  fclose($fp);
  ?>
<?php include_once "footer.php" ?>
