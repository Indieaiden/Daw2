<!DOCTYPE html>
<html lang="es">

<head>
		<title>Mi primera página html</title>
		<meta charset="UTF-8">
		<meta name="description" content="Mi primera página">
		<meta name="author" content="Pablo">
		<link rel="stylesheet" type="text/css" href ='./estilo.css'>
</head>		
	
	<body>
		
			
	
	