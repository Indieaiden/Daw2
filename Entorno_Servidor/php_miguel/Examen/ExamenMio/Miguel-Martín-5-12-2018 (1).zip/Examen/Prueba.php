<?php
 // $x = new DateTime(new DateInterval());
 // $y = new DateTime('2000-12-10');
 // $z = date_create('');
 // echo"$x";
 // echo"$y";
 // echo date_format($z,'y-m-d');
	define("ERROR_NOREGISTRADO",-1);
	echo constant('ERROR_NOREGISTRADO');
?>